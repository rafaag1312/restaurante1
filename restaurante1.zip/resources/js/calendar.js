$(document).ready(function() {
    var calendar = $('#calendar').fullCalendar({
        events: eventsArray
    });
});