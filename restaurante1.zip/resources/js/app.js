import './bootstrap';
require('fullcalendar');
require('jquery');